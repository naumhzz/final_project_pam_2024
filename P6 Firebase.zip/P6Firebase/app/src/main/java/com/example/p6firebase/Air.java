package com.example.p6firebase;

public class Air {
    private String id;
    private String waktu;
    private String jumlahAir;

    public Air() {}

    public Air(String id, String waktu, String jumlahAir) {
        this.id = id;
        this.waktu = waktu;
        this.jumlahAir = jumlahAir;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getJumlahAir() {
        return jumlahAir;
    }

    public void setJumlahAir(String jumlahAir) {
        this.jumlahAir = jumlahAir;
    }
}
