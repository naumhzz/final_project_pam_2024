package com.example.p6firebase;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FragmentBawah extends Fragment {
    private RecyclerView rvRiwayat;
    private AirAdapter adapterAir;
    private List<Air> daftar;
    private SharedViewModel viewModel;

    public FragmentBawah() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        daftar = new ArrayList<>();
        adapterAir = new AirAdapter(requireContext(), daftar);

        viewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_bawah, container, false);
        rvRiwayat = v.findViewById(R.id.rvRiwayat);
        rvRiwayat.setLayoutManager(new LinearLayoutManager(getContext()));
        rvRiwayat.setAdapter(adapterAir);

        Button btRiwayat = v.findViewById(R.id.btRiwayat);
        btRiwayat.setOnClickListener(this::tampilkanRiwayat);
        return v;
    }

    public void tampilkanRiwayat(View view) {
        Log.d("FragmentBawah", "Tombol Riwayat diklik");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference reference = database.getReference("Air");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                daftar.clear();
                int totalIntake = 0;

                for (DataSnapshot data : snapshot.getChildren()) {
                    Air air = data.getValue(Air.class);
                    if (air != null) {
                        daftar.add(air);
                        totalIntake += Integer.parseInt(air.getJumlahAir().replace("ML", ""));
                    }
                }

                adapterAir.notifyDataSetChanged();
                viewModel.setCurrentIntake(totalIntake);

                Log.d("FragmentBawah", "Data dari Firebase: " + daftar.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(requireContext(), "Gagal Memuat Data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
